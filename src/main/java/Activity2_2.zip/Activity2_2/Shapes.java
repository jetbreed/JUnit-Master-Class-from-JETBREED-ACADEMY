package Activity2_2;

public interface Shapes {
    public void draw();
}
